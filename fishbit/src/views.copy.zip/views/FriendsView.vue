<template>
  <div class="friends-view">
    <div class="container-fluid p-4">
      <h2>Friends</h2>
      <p>Connect with friends - Coming soon!</p>
    </div>
  </div>
</template>

<script setup>
</script>

<style scoped>
.friends-view {
  min-height: calc(100vh - 70px);
  background: #f8f9fa;
}
</style>