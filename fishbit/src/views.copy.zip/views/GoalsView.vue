<template>
  <div class="goals-view">
    <div class="container-fluid p-4">
      <h2>Goals</h2>
      <p>Track your progress - Coming soon!</p>
    </div>
  </div>
</template>

<script setup>
</script>

<style scoped>
.goals-view {
  min-height: calc(100vh - 70px);
  background: #f8f9fa;
}
</style>